<?php

namespace Tabby\Checkout\Model\Method;

class Installments extends Checkout
{
    /**
     * @var string
     */
    protected $_code = 'tabby_installments';

}
